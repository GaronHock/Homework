import { RECEIVE_ALL_POKEMON } from '../actions/pokemon_actions';

// const fruitReducer = (state = [], action) => {
//   Object.freeze(state);
//   switch (action.type) {
//     case "ADD_FRUIT":
//       return [...state, action.fruit];
//     default:
//       return state;
//   }
// };

export const pokemonReducer = (state= {}, action) =>{
    Object.freeze(state);
    switch(action.type){
      case RECEIVE_ALL_POKEMON:
        return action.pokemon;  
      default:
        return state;
    }
    
}