class Piece

    attr_reader :value

    def initialize(value)
        @value = Piece.new(:Y)
    end

   



end