class BandsController < ApplicationController

    def index
        render :new
    end

end