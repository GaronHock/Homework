

class NullPiece
    def initialize
        @color = cpole
    end
end