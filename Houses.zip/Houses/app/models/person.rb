class Person < ActivationRecord
    
end