
export const selectAllPokemon = ({ pokemon }) => (
    Object.values(pokemon).map(id => pokemon[id])
)