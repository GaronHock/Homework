class Band < ApplicationRecord
    
    validates :name, presence: true
end
